    <div class="head">
        <div class="container head-content">
            <div class="row">
               <div class ="col-xs-12 col-sm-12">
                   <h1 class="text-justify">Welcome to our Blog</h1>
                   <img src="static/img/procoder-background-dark.jpg" class="img-head"></img>
                   
               </div>                
            </div>
        </div>
        
    </div>
