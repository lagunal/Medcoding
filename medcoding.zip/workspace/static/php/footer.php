<footer>
<div class="copy-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12"><div class="text-center footer">Copyrigth © 2015, Powered by NimbusPC</div></div>
        </div>
    </div>
</div>
</footer>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="static/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="static/js/bootstrap.min.js"></script>
</body>
</html>